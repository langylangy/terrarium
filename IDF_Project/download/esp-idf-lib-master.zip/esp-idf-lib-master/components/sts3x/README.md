# Driver for STS3x digital temperature sensor

This driver is fork of SHT3x driver excluding humidity measurements.