.. _impulse_sensor:

impulse_sensor - Driver for sensors with impulse output like 
fluid flow, shaft rotation, windspeed sensors.
=================================================================

.. doxygengroup:: impulse_sensor
   :members:

