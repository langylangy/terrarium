.. _scd30:

scd30 - Driver for SCD30 CO₂ sensor
===================================

.. doxygengroup:: scd30
   :members:

