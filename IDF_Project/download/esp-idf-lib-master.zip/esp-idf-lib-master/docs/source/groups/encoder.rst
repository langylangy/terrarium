.. _encoder:

encoder - Driver for incremental rotary encoders
================================================

.. doxygengroup:: encoder
   :members:

